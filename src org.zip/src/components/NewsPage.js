import React from 'react';

function NewsPage() {
  return (
    <div>
      <h1>Latest News</h1>
      <p>Stay updated with the latest news relevant to the farming industry and more.</p>
    </div>
  );
}

export default NewsPage;
